


var app = angular.module('app', ['ui.router']);
app.config(['$stateProvider', function ($stateProvider) {
  $stateProvider
    .state('register', {
      url: '/register',
      templateUrl: 'register/register.html',
      controller:'register'
    })
    .state('login', {
      url: '/login',
     
      templateUrl: 'login/login.html',
      controller:'login'
    })
    .state('dashboard', {
      url: '/dashboard',
      templateUrl: 'dashboard/dashboard.html',
      controller:'dashboard'
    })
    .state('home', {
      url: '/home',
      templateUrl: 'home/home.html'
      
    })
    .state('shop', {
      url: '/shop',
      params : {
        username : ''
      },
      templateUrl: 'shop/shop.html',
      controller : 'shop'
      
    })
    .state('description', {
      url: '/description/:name/:price/:img/:username',
      
      templateUrl: 'description/description.html',
      controller : 'description'
      
    })
    .state('cart', {
      url: '/cart',
      params : {
       
        username : '',
        price : '',
       
       
      },
      templateUrl: 'cart/cart.html',
      controller : 'cart'
      
    })
    .state('root', {
    url: '/',
    template: '<h1>Welcome</h1>'
  });
}]);







app.controller('dashboard', function ($scope, $state) {
  $scope.userName = localStorage.getItem('name');
  $scope.email = localStorage.getItem('email');
  $scope.mobile = localStorage.getItem('mobile');
  $scope.dob = localStorage.getItem('dob');
  $scope.logout = function () {
    window.localStorage.clear();
    $state.go("register");
};
});




