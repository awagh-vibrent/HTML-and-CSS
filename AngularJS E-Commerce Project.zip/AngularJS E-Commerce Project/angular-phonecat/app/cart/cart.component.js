
angular.module('app').component('cartcomponent',{
    template : '<cart-component></cart-component>'
})


app.controller('cart',function($scope,$stateParams){

    $scope.price = $stateParams.price;
    $scope.username = $stateParams.username
    
    
    })