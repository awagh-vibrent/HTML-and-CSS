
angular.module('app').component('descriptioncomponent',{
    template : '<description-component></description-component>'
})



app.controller('description',function($scope, $stateParams,$rootScope,$http,$state){

    $scope.user = localStorage.getItem("username");

    $scope.img = $stateParams.img;
    let id;
    $scope.name = $stateParams.name;
    $scope.price = $stateParams.price;
    $scope.username = $stateParams.username
    let username = $stateParams.username;
    
    
    
    $scope.qty = document.getElementById('qty').value ;
    
    
    
    $scope.edit = function (name,price,newname,newprice){
      
      $http.get('https://62de7bd9ccdf9f7ec2d94678.mockapi.io/product')
      .then(function(response){
        
        $scope.arr;
        arr = response.data;
        console.log(arr);
        console.log(name,price);
    
        for(let i = 0; i < arr.length ; i++){
            $scope.arr = arr;
            
          if(name == arr[i].Title && price == arr[i].Price){
            
            id = arr[i].id
            console.log(arr[i].id); 
             
             alert("Details Changed");
             
    
            var data = {
              Title : newname,
              Price : newprice,
              id : id
            }
    
           $http.put(`https://62de7bd9ccdf9f7ec2d94678.mockapi.io/product/${id}`,data)
            .then(function(response){
    
            })
          }
        }
        
        
      });
      },
    
     
    $scope.cart = function (price,qty){
    
    var data = {
      
      price : price,
      qty : qty
    }
    
    
    
    price = price * qty;
    
    
      $http.post('https://62de7bd9ccdf9f7ec2d94678.mockapi.io/cart',data)
      .then(function(response){
        
      })
      $state.go('cart',{
        
        username : username ,
        price : price
      });
    
    }
    
    
    
    
    });
    