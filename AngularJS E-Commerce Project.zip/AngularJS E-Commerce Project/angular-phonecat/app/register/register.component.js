
angular.module('app').component('registercomponent',{
    template : '<register-component></register-component>'
})



app.controller('register', function ($scope,$state,$http) {
 
    $scope.postdata = function (name,email,phone,password,add) {
     
        localStorage.setItem("user",name);

      var data = {
        name : name,
        email : email,
        phone : phone,
        password : password,
        add : add
      }
          
       $http.post("https://62de7bd9ccdf9f7ec2d94678.mockapi.io/users",JSON.stringify(data))
       .then(function(response){
        console.log(response);
        
       })
       
       alert("Form submitted Successfully....!!!");
        $state.go("shop")
     
      };
  });