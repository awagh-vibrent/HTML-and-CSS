angular.module('app').component('shopcomponent',{
    template : '<shop-component></shop-component>'
})




app.controller('shop',function($scope,$http,$stateParams){
    $scope.user = localStorage.getItem("username");
    $scope.user = $stateParams.username;
    $scope.username  = $stateParams.username;
  
  $scope.employees ;
  
  
  $http.get('https://62de7bd9ccdf9f7ec2d94678.mockapi.io/product')
  .then(function(response){
    employees = response.data;
  
    $scope.employees = chunkArrayInGroups(employees, 3);
  
    function chunkArrayInGroups(arr, size) {
    var myArray = [];
    for (var i = 0; i < arr.length; i += size) {
      myArray.push(arr.slice(i, i + size));
    }
    return myArray;
  }
  
  
  
  
  }); 
  
  /*
  function pass(name,price,img){
    
  
    $state.go('description',{
      name : name,
      price : price,
      img : img
    })
  
  }
  */
  });
  