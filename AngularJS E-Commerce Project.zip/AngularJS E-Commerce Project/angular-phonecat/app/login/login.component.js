
angular.module('app').component('logincomponent',{
    template : '<login-component></login-component>'
})


app.controller('login', function ($scope,$rootScope,$state,$http) {
    $rootScope.isUserLoggedIn = false;
    $scope.arr;
    $scope.email;
    $scope.password ;
    $scope.username;
  
    $scope.loginform = function (email,password) {
      email = email;
     password = password;
        $http.get('https://62de7bd9ccdf9f7ec2d94678.mockapi.io/users')
        .then(function(response){
  
          arr = response.data;
  
          console.log(arr);
        
        });
        for(let i = 0 ; i < arr.length ; i++){
          if(email == arr[i].email && password == arr[i].password){
            console.log('Found');
            username = arr[i].name;
            localStorage.setItem("username",username);
            $rootScope.isUserLoggedIn = true;
            alert('LoginSuccessfull')
            $state.go("shop",{
              username : username
            })
          }
        }
  
    
  
    }});